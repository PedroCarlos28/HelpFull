<?php
// grafico_humor.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Não logado']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

try {
    // Esse SQL pega SOMENTE humores do usuário logado,
    // filtrando pelo mês atual.
    $sql = "
        SELECT 
            humor,
            DATE(data_criacao) AS data
        FROM diarios
        WHERE usuario_id = ?
        ORDER BY data_criacao DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario_id]);

    $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'sucesso' => true,
        'dados' => $dados
    ]);

} catch (PDOException $e) {
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro SQL: ' . $e->getMessage()
    ]);
}
?>
