document.addEventListener("DOMContentLoaded", function () {

  // === Abrir e fechar chat ===
  const chatModule = document.getElementById("chatModule");
  const openChatBtn = document.getElementById("openChatBtn");
  const closeChatBtn = document.getElementById("closeChatBtn");

  openChatBtn.addEventListener("click", () => {
    chatModule.classList.add("chat-module--visible");
    openChatBtn.classList.add("chat-float-btn--hidden");
  });

  closeChatBtn.addEventListener("click", () => {
    chatModule.classList.remove("chat-module--visible");
    openChatBtn.classList.remove("chat-float-btn--hidden");
  });

  // === Enviar mensagem ===
  const input = document.getElementById("mensagem");
  const chatBody = document.getElementById("chatBody");
  const sendBtn = document.getElementById("sendMsgBtn");

  async function enviarMensagem() {
    const texto = input.value.trim();
    if (texto === "") return;

    // mostra mensagem do usuário
    addMessage(texto, "user-msg");

    input.value = "";

    // envia ao backend
    const response = await fetch("http://localhost:5000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: texto })
    });

    const data = await response.json();

    // mostra resposta do bot
    addMessage(data.reply, "bot-msg");
  }

  sendBtn.addEventListener("click", enviarMensagem);
  input.addEventListener("keypress", function (e) {
    if (e.key === "Enter") enviarMensagem();
  });

  function addMessage(text, cssClass) {
    const msg = document.createElement("div");
    msg.classList.add(cssClass);
    msg.innerText = text;
    chatBody.appendChild(msg);
    chatBody.scrollTop = chatBody.scrollHeight;
  }
});
