<?php
// config.php

// 1. Define o fuso horário (Importante para os gráficos baterem com o dia certo)
date_default_timezone_set('America/Sao_Paulo');

// 2. SESSÃO SEGURA (A mudança principal é aqui)
// O código abaixo diz: "Se a sessão AINDA NÃO EXISTIR, inicie ela".
// Isso resolve seu medo de duplicar a sessão e também resolve o problema dos gráficos sumindo.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3. Conexão com o Banco (Mantive seus dados)
$host = 'localhost';
$db   = 'helpfull'; // Nome do seu banco
$user = 'root';
$pass = '';

try {
    // Cria a conexão PDO (Fundamental para os gráficos funcionarem)
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);

    // Configura para dar erro fatal se algo der errado no banco (ajuda a achar bugs)
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Mata o script se não conectar
    die("Erro de conexão com o banco de dados: " . $e->getMessage());
}
?>