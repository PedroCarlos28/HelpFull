<?php
// verificar_sessao.php

// Inicia a sessão (com a trava de segurança)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Verifica se a variável de sessão existe
if (isset($_SESSION['usuario_id'])) {
    echo json_encode(['logado' => true]);
} else {
    echo json_encode(['logado' => false]);
}
?>