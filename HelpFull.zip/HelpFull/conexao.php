<?php
$host = "localhost";
$usuario = "root";
$senha = ""; // ou a senha do seu MySQL
$banco = "helpfull";

$conn = new mysqli($host, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

header('Content-Type: application/json; charset=utf-8');

?>
