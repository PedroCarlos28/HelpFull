<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
session_start();

require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não logado.']);
    exit;
}

$id_usuario = $_SESSION['usuario_id'];

try {
    $pdo->beginTransaction();

    $stmt1 = $pdo->prepare("DELETE FROM diarios WHERE usuario_id = :id");
    $stmt1->execute([':id' => $id_usuario]);

    $stmt2 = $pdo->prepare("DELETE FROM usuarios WHERE id = :id");
    $stmt2->execute([':id' => $id_usuario]);

    $pdo->commit();

    session_unset();
    session_destroy();

    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'Conta apagada com sucesso!'
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro ao excluir conta: ' . $e->getMessage()
    ]);
}
