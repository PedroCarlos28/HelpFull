<?php
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Não logado']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

try {
    $stmt_user = $pdo->prepare("SELECT nome, email FROM usuarios WHERE id = ?");
    $stmt_user->execute([$usuario_id]);
    $user_info = $stmt_user->fetch(PDO::FETCH_ASSOC);

    $stmt_diarios = $pdo->prepare("
        SELECT texto_diario, humor, DATE(data_criacao) AS data_criacao
        FROM diarios 
        WHERE usuario_id = ? 
        ORDER BY data_criacao DESC, id DESC
    ");
    $stmt_diarios->execute([$usuario_id]);
    $historico = $stmt_diarios->fetchAll(PDO::FETCH_ASSOC);

    if ($user_info) {
        echo json_encode([
            'sucesso' => true,
            'info' => $user_info,
            'historico_completo' => $historico
        ]);
    } else {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não encontrado.']);
    }

} catch (Exception $e) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Erro: ' . $e->getMessage()]);
}
?>