<?php
// salvar_diario.php

// 1. O MAIS IMPORTANTE: Iniciar a sessão antes de qualquer coisa
// Verifica se a sessão já não está aberta para evitar erros
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Inclui a conexão com o banco de dados
// Nota: Certifique-se que o arquivo 'config.php' cria a variável $pdo
require_once 'config.php';

header('Content-Type: application/json');

$response = ['sucesso' => false, 'mensagem' => ''];

// 3. Agora o PHP consegue ler a sessão criada no login
if (!isset($_SESSION['usuario_id'])) {
    $response['mensagem'] = 'Sessão expirada ou usuário não autenticado.';
    $response['codigo_erro'] = 'NAO_LOGADO';
    echo json_encode($response);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$data = json_decode(file_get_contents('php://input'), true);

$texto = $data['texto'] ?? '';
$humor = $data['humor'] ?? '';

if (empty($texto) || empty($humor)) {
    $response['mensagem'] = 'O texto e o humor são obrigatórios.';
    echo json_encode($response);
    exit;
}

try {
    // Insere a nova anotação usando PDO (garanta que seu config.php usa PDO)
    $stmt = $pdo->prepare("INSERT INTO diarios (usuario_id, texto_diario, humor, data_criacao) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$usuario_id, $texto, $humor]);

    $response['sucesso'] = true;
    $response['mensagem'] = 'Diário salvo com sucesso!';

} catch (PDOException $e) {
    $response['mensagem'] = 'Erro no banco de dados: ' . $e->getMessage();
}

echo json_encode($response);
?>