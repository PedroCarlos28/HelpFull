<?php
header('Content-Type: application/json; charset=utf-8');
session_start();

include('conexao.php');

$dados = json_decode(file_get_contents("php://input"), true);

$nome = $dados['nome'] ?? '';
$email = $dados['email'] ?? '';
$senha = $dados['senha'] ?? '';

if (!$nome || !$email || !$senha) {
    echo json_encode(["sucesso" => false, "mensagem" => "Preencha todos os campos."]);
    exit;
}

$hash = password_hash($senha, PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nome, $email, $hash);

if ($stmt->execute()) {
    $novo_id = $stmt->insert_id;

    $_SESSION['usuario_id'] = $novo_id;
    $_SESSION['usuario_nome'] = $nome;

    echo json_encode([
        "sucesso" => true,
        "mensagem" => "Cadastro e login automáticos realizados com sucesso!",
    ]);

} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Erro ao cadastrar (email pode já existir)."]);
}

$stmt->close();
$conn->close();
?>