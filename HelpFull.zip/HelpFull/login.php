<?php
session_start();
include('conexao.php');

$dados = json_decode(file_get_contents("php://input"), true);

$email = $dados['email'] ?? '';
$senha = $dados['senha'] ?? '';

if (!$email || !$senha) {
    echo json_encode(["sucesso" => false, "mensagem" => "Preencha todos os campos."]);
    exit;
}

$stmt = $conn->prepare("SELECT id, senha FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    if (password_verify($senha, $user['senha'])) {
        $_SESSION['usuario_id'] = $user['id'];
        echo json_encode(["sucesso" => true]);
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "Senha incorreta."]);
    }
} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Usuário não encontrado."]);
}

$stmt->close();
$conn->close();

header('Content-Type: application/json; charset=utf-8');

?>
