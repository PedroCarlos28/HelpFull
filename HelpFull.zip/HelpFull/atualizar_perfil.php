<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["sucesso" => false, "mensagem" => "Não logado."]);
    exit;
}

$dados = json_decode(file_get_contents("php://input"), true);
$id = $_SESSION['usuario_id'];
$nome = $dados['nome'] ?? '';
$email = $dados['email'] ?? '';
$senha = $dados['senha'] ?? '';

if (!$nome || !$email) {
    echo json_encode(["sucesso" => false, "mensagem" => "Nome e email são obrigatórios."]);
    exit;
}

if ($senha) {
    $hash = password_hash($senha, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE usuarios SET nome=?, email=?, senha=? WHERE id=?");
    $stmt->bind_param("sssi", $nome, $email, $hash, $id);
} else {
    $stmt = $conn->prepare("UPDATE usuarios SET nome=?, email=? WHERE id=?");
    $stmt->bind_param("ssi", $nome, $email, $id);
}

if ($stmt->execute()) {
    echo json_encode(["sucesso" => true]);
} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Erro ao atualizar."]);
}

header('Content-Type: application/json; charset=utf-8');

?>

