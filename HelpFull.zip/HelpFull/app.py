from flask import Flask, request, jsonify
from flask_cors import CORS
import os

from google import genai
from google.genai import types

app = Flask(__name__)
CORS(app)  # Permitir que o frontend acesse o backend

os.environ["GOOGLE_API_KEY"] = "AIzaSyCyW-tpBrcythyJ9l-zKLngxDH-HabNCJE"

client = genai.Client()
model = "gemini-2.5-flash"

chat_config = types.GenerateContentConfig(
    system_instruction=(
        "Você é um assistente especializado em saúde mental. "
        "Ajuda pessoas a compreender sentimentos e oferece apoio emocional. "
        "Se sair do tema, lembre o usuário do propósito."
    )
)

@app.route("/chat", methods=["POST"])
def chat():
    user_msg = request.json.get("message", "")

    response = client.models.generate_content(
        model=model,
        contents=user_msg,
        config=chat_config
    )

    reply = response.text if hasattr(response, "text") else "Erro."

    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(port=5000, debug=True)
