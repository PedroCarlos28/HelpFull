<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Não logado']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

try {
    $meses = 6;
    $hoje = new DateTime('now');
    $inicio = (clone $hoje)->modify("first day of -".($meses-1)." months")->format('Y-m-d 00:00:00');

    $sql = "
        SELECT 
            YEAR(data_criacao) AS ano,
            MONTH(data_criacao) AS mes,
            COUNT(*) AS total
        FROM diarios
        WHERE usuario_id = ?
          AND data_criacao >= ?
        GROUP BY YEAR(data_criacao), MONTH(data_criacao)
        ORDER BY ano ASC, mes ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario_id, $inicio]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $map = [];
    foreach ($rows as $r) {
        $key = $r['ano'] . '-' . str_pad($r['mes'], 2, '0', STR_PAD_LEFT);
        $map[$key] = (int) $r['total'];
    }

    $resultado = [];
    $cursor = new DateTime($inicio);

    for ($i = 0; $i < $meses; $i++) {
        $ano = $cursor->format('Y');
        $mes = $cursor->format('n');

        $key = $ano . '-' . str_pad($mes, 2, '0', STR_PAD_LEFT);
        $total = $map[$key] ?? 0;

        $resultado[] = [
            'ano' => (int)$ano,
            'mes' => (int)$mes,
            'total' => $total
        ];

        $cursor->modify('+1 month');
    }

    echo json_encode(['sucesso' => true, 'dados' => $resultado]);

} catch (PDOException $e) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Erro SQL: ' . $e->getMessage()]);
}
?>
