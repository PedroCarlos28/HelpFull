document.addEventListener('DOMContentLoaded', () => {
    const formLogin = document.getElementById('form-login');
    const formCadastro = document.getElementById('form-cadastro');

    const signUpBtn = document.getElementById('sign-up-btn');
    const signInBtn = document.getElementById('sign-in-btn');
    const container = document.querySelector('.container');

    formLogin.addEventListener('submit', async (e) => {
        e.preventDefault();

        const email = document.getElementById('login-email').value.trim();
        const senha = document.getElementById('login-senha').value.trim();

        try {
            const resposta = await fetch('login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, senha })
            });

            const data = await resposta.json();

            if (data.sucesso) {
                window.location.href = 'Inicio.html';
            } else {
                alert('Erro: ' + data.mensagem);
            }
        } catch (error) {
            console.error('Erro ao fazer login:', error);
            alert('Erro de conexão ao tentar logar.');
        }
    });

    formCadastro.addEventListener('submit', async (e) => {
        e.preventDefault();

        const nome = document.getElementById('cadastro-nome').value.trim();
        const email = document.getElementById('cadastro-email').value.trim();
        const senha = document.getElementById('cadastro-senha').value.trim();

        try {
            const resposta = await fetch('cadastro.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome, email, senha })
            });

            const data = await resposta.json();

            if (data.sucesso) {
                window.location.href = 'Inicio.html';
            } else {
                alert('Erro: ' + data.mensagem);
            }
        } catch (error) {
            console.error('Erro ao cadastrar:', error);
            alert('Erro de conexão ao tentar cadastrar.');
        }
    });

    signUpBtn.addEventListener('click', () => container.classList.add('sign-up-mode'));
    signInBtn.addEventListener('click', () => container.classList.remove('sign-up-mode'));
});