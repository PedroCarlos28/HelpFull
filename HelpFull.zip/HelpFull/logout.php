<?php
session_start();
session_destroy();
header("Location: comeco.html");
exit;

header('Content-Type: application/json; charset=utf-8');

?>
